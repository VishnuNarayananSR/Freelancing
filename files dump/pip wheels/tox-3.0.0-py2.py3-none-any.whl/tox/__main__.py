from tox.session import run_main

if __name__ == '__main__':
    run_main()
